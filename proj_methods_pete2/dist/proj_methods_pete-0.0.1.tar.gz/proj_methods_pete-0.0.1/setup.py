from setuptools import setup

setup(name='proj_methods_pete',
      version='0.0.1',
      description='custom method package',
      packages=['proj_methods_pete'],
      author='Pete Tae',
      email='pete.taecha@gmail.com',
      zip_safe=False)
